public class Snailbox extends Animal{
    public Snailbox() {
        super("Snailbox", 8, 5, 1, true);
    }
}
