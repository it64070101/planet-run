public class FLowLayout {

    public static final Object RIGHT = null;

}
