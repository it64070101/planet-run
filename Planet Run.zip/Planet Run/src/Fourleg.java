public class Fourleg extends Animal {
    public Fourleg() {
        super("Fourleg", 6, 4, 1, true);
    }
}
