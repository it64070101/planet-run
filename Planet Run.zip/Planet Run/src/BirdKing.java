public class BirdKing extends Animal {
    public BirdKing() {
        super("Bird King", 5, 3, 1, true);
    }
}
