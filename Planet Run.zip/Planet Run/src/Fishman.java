public class Fishman extends Animal{
    public Fishman() {
        super("Fishman", 7, 4, 2, true);
    }
}
