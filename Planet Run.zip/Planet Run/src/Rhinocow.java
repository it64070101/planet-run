public class Rhinocow extends Animal{
    public Rhinocow() {
        super("rhinocow", 9, 5, 2, true);
    }
}
