public class DoubleDog extends Animal {
    public DoubleDog() {
        super("Double Dog", 4, 3, 2, true);
    }
}

